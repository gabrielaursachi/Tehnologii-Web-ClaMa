// Tema0_GA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <ctime>
#include <time.h>
#include<random>
using namespace std;

double a = -10, b = 10, x[10], y[10], z[10];
int m, k, n = 2;

double SumSquare(int n, double x[10])
{
	double sum = 0;
	for(int i=1; i <= n ; i++)
		sum = sum + i * x[i] * x[i];

	return sum;
}

double DixonPrice(int n, double x[10])
{
	
	double sum = 0;
	for (int i=2; i <= n; i++)
		sum = sum + i * (2 * x[i] * x[i] - x[i - 1]) * (2 * x[i] * x[i] - x[i - 1]);
	
	sum+= (x[1] - 1) * (x[1] - 1);
		return sum;
}

void generare(double x[10])
{
	random_device s;
	mt19937 gen(s());
	uniform_real_distribution<double> dist(a, b);

	for (int i = 1; i <= n; i++)
	{
		x[i] = dist(s);
	}
}

double minimSS_euristic(int m)
{
	double minimSS = INFINITY;
	for (int i = 1; i <= m; i++)
	{
		generare(x);
		double aux = SumSquare(n, x);
		if (aux < minimSS)
			minimSS = aux;
	}
	return minimSS;
}

double minimDP_euristic(int m)
{
	double minimDP = INFINITY;
	for (int i = 1; i <= m; i++)
	{
		generare(x);
		double aux = DixonPrice(n, x);
		if (aux < minimDP)
			minimDP = aux;
	}
	return minimDP;
}

int main()
{
	clock_t start_d = clock();
	
	double st = a;
	double minimSS_det = INFINITY;
	while (st <= b)
	{
		if (m==1)
		{
			//double aux = SumSquare(m, y);
			//cout << val << " \n";
			if (SumSquare(m, y) < minimSS_det)
				minimSS_det = SumSquare(m, y);

			y[m] = { 0 };
			/*
			cout << st << "==>";
			for (int i = 0; i < m; i++)
				cout << y[i]<<" ";
			cout << endl;
			*/
			m = 0;
		}
			
		y[m++] = st;
		st += 0.5;
	}	
	
	clock_t end_d = clock();
	cout << "minim SumSquare (determinist) : " << minimSS_det << "\n";
	cout << "SumSquare TIME (determinist) : " << double(end_d - start_d) / CLOCKS_PER_SEC << '\n';
	cout << '\n';

	st = a;
	double minimDP_det = INFINITY;
	while (st <= b)
	{
		if (k==1)
		{
			double val = DixonPrice(k, z);
			//cout << val << " \n";
			if (val < minimDP_det)
				minimDP_det = val;
			z[k] = { 0 };
			k = 0;
		}

		z[k++] = st;
		st += 0.5;
	}

	cout << "minim Dixon&Price (determinist) : " << minimDP_det << "\n";
	
	cout<<'\n';
	
	clock_t start = clock();
	cout << "minim SumSquare (euristic) : " << minimSS_euristic(1000) << "\n";
	clock_t end = clock();
	cout << "SumSquare TIME (euristic) : " << double(end - start) / CLOCKS_PER_SEC<<'\n';

	cout << '\n';

	clock_t start1 = clock();
	cout << "minim Dixon&Price (euristic) : " << minimDP_euristic(1000) << "\n";
	clock_t end1 = clock();
	cout << "Dixon&Price TIME (euristic) : " << double(end1 - start1) / CLOCKS_PER_SEC << '\n';

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
