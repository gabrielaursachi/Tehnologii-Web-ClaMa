// Tema1_GA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include<fstream>
#include <random>
#include<math.h>
#include <cmath>
#include <cstdlib>
#include<vector>
#include<iomanip>
#include <time.h>
using namespace std;
ofstream fout("results.txt");
# define pi  3.14159265358979323846 

double Rastrigin(vector<double> v, int n)
{
    double s = 0;
	for (int i = 0; i <n; i++)
	{
		s = s + (v[i] * v[i] - 10 * cos(2 * pi * v[i]));
	}
     
    return  (10*n + s);
}

double DeJong(vector<double> v, int n)
{
	double s = 0;
	for (int i = 0; i < n; i++)
		s += v[i] * v[i];
	return s;
}

double Michalewicz(vector<double> v, int n)
{
	int m = 10;
	double s = 0;
	for (int i = 0; i < n; i++)
	{
		s = s + sin(v[i]) * pow((sin(i * v[i] * v[i] / pi)), (2 * m));
	}

	return -s;
}
/*
double Rosenbrock(vector<double> v, int n)
{
	double s = 0;
	for(int j=0; j<n-1; j++)
	s += 100 * (v[j] * v[j] - v[j + 1]) * (v[j] * v[j] - v[j + 1]) + (v[j] - 1) * (v[j] - 1);
	
	return s;
}
*/
double Ackley(vector<double> v, int n)
{
	double s1 = 0, s2 = 0;
	for (int i = 0; i < n; i++)
	{
		s1 += v[i] * v[i];
		s2 += cos(2 * pi * v[i]);
	}
	return -20 * exp(-0.2 * sqrt(1 / double(n) * s1)) - exp(1 / double(n) * s2) + 20 + exp(1);
}
/*double Schwefel(vector<double> v, int n)
{
	double s = 0;
	for (int i = 0; i < n; i++)
		s += (-v[i] * sin(sqrt(abs(v[i]))));

	return 418.9829 *(-n) + s;
}
*/
void random(int n, int v[100])
{
	uniform_int_distribution<int> d(0, 1);
	mt19937 s;
	s.seed(random_device{}());

	for (int i = 0; i < n; i++)
	{
		v[i] = d(s);
	}
}

vector<double> convert_dec(int hill[1000], int n, int precizie, int m, double a, double b)
{
	vector<double> v;
	int val, p = pow(10, precizie);

	for (int j = 0; j < n; j++)
	{
		val = 0;
		int count = 0;
		//sectionam lungimea de m biti in l biti
		for (int i = j * m; i < (j + 1) * m; i++)
		{
			//cout << "i = " << i << " val = "<< val << endl;
			val = val * 2;
			val += hill[i];
		}
		float number = val / ((pow(2, m)) - 1);
		double sol = number * (b - a) + a;
		v.push_back((sol));
		/*
		cout << endl;
		for (int k = 0; k < m; k++)
			cout << hill[k] << " ";
		cout << endl;
		*/
	}

	return v;
}

void improve(int aux[1000], int hill[1000], int pos, int dim)
{
	/*
	cout << "pozitia este " << pos << endl;

	for (int i = 0; i < dim; i++)
		cout << hill[i];
	cout << endl;
	*/
	for (int i = 0; i < dim; i++)
		aux[i] = hill[i];

	if (hill[pos] == 0) 
		aux[pos] = 1;
	else 
		aux[pos] = 0;
	
	/*
	for (int i = 0; i < dim; i++)
		cout << aux[i];
	cout << endl;
	*/
	
}

double BIHC(int it, double a, double b, int precizie, int n, int f) //best improvement hill climbimng; n=nr dimensiuni
{
	int min_hill[1000], hill[1000]; //hill pt flip bit (auxiliar)
	int m = ceil(log2((b - a) * pow(10, precizie))); // dimensiune vector biti
	//cout << m << endl;
	double min, fitness;
	vector<double> v, min_fitnesses;
				
		for (int i = 0; i < it; i++)
		{
			random(m * n, min_hill); // generez array de biti
			v = convert_dec(min_hill, n, precizie, m, a, b);
			switch (f)
			{
			case 1: {fitness = Rastrigin(v, n); break; }
			case 2: {fitness = DeJong(v, n); break; }
			case 3: {fitness = Michalewicz(v, n); break; }
			case 4: {fitness = Ackley(v, n); break; }
			}
			min = fitness;

			for(int k=0; k < m*n; k++)
			{	
				improve(hill, min_hill, k, m * n);
				v = convert_dec(hill, n, precizie, m, a, b);
				switch (f)
				{
				case 1: {fitness = Rastrigin(v, n); break; }
				case 2: {fitness = DeJong(v, n); break; }
				case 3: {fitness = Michalewicz(v, n); break; }
				case 4: {fitness = Ackley(v, n); break; }
				}
				
				if (fitness < min)
				{
					min = fitness;
					min_fitnesses.push_back(min);
					for (int i = 0; i < m * n; i++)
						min_hill[i] = hill[i];
					
				}				
			}
		}
		
	double min_abs = INFINITY;
	for (int i = 0; i < min_fitnesses.size(); i++)
		if (min_fitnesses[i] < min_abs)
			min_abs = min_fitnesses[i];

	return min_abs;
}

double FIHC(int it, double a, double b, int precizie, int n, int f) // first improvement hill climbing
{
	int min_hill[1000], hill[1000];
	int m = ceil(log2((b - a) * pow(10, precizie)));
	double min = INFINITY, fitness;
	vector<double> x, min_fitnesses;

	for (int i = 0; i < it; i++)
	{
		random(m * n, min_hill);
		x = convert_dec(min_hill, n, precizie, m, a, b);
		
		switch (f)
		{
		case 1: {fitness = Rastrigin(x, n); break; }
		case 2: {fitness = DeJong(x, n); break; }
		case 3: {fitness = Michalewicz(x, n); break; }
		case 4: {fitness = Ackley(x, n); break; }
		}

		bool flag = true;
		while (flag)
		{
			flag = false;
			for (int j = 0; j < m * n; j++)
			{
				//cout << "j == " << j << endl;
				improve(hill, min_hill, j, m * n);
				x = convert_dec(hill, n, precizie, m, a, b);
				switch (f)
				{
				case 1: {fitness = Rastrigin(x, n);  break; }
				case 2: {fitness = DeJong(x, n); break; }
				case 3: {fitness = Michalewicz(x, n); break; }
				case 4: {fitness = Ackley(x, n); break; }
				}

				if (fitness < min)
				{
					min = fitness;
					min_fitnesses.push_back(min);
					for (int i = 0; i < m * n; i++)
						min_hill[i] = hill[i];
					flag = true;
				}
			}

		}
	}
	double abs_min = INFINITY;
	int dim = min_fitnesses.size();
	for (int i = 0; i < dim; i++)
	{
		//cout << "I'm in for loop "<< min_fitnesses[i]<<" \n";
		if (min_fitnesses.at(i) < abs_min) 
			abs_min = min_fitnesses.at(i);
	}
	
	return  abs_min;
}

double SA(int min_iteration,  double a, double b, int precizie, double step, int n,  int f)
{
	int min_hill[1000], hill[1000], m = ceil(log2((b - a) * pow(10, precizie))), pos, probability;
	double min_fitness, fitness, acceptance_probability, temperature, first_temperature;
	vector<double> v, min_fitnesses;
	first_temperature = temperature = 110;
	random(m * n, min_hill);
	
	//clock_t tStart1 = clock();
	v = convert_dec(min_hill, n, precizie, m, a, b);
	switch (f)
	{
	case 1: {fitness = Rastrigin(v, n); break; }
	case 2: {fitness = DeJong(v, n); break; }
	case 3: {fitness = Michalewicz(v, n); break; }
	case 4: {fitness = Ackley(v, n); break; }
	}
	min_fitness = fitness;

	int k = 0;
	while (temperature > pow(10, -8))
	{
		for (int i = 0; i < min_iteration; i++)
		{
			uniform_int_distribution<int> dist(0, m * n);
			mt19937 s;
			s.seed(random_device{}());

			pos = dist(s);

			improve(hill, min_hill, pos, m * n);

			v = convert_dec(hill, n, precizie, m, a, b);

			switch (f)
			{
			case 1: {fitness = Rastrigin(v, n); break; }
			case 2: {fitness = DeJong(v, n); break; }
			case 3: {fitness = Michalewicz(v, n); break; }
			case 4: {fitness = Ackley(v, n); break; }
			}

			if (fitness < min_fitness)
			{
				min_fitness = fitness;
				for (int i = 0; i < m * n; i++)
					min_hill[i] = hill[i];
			}
			else
			{

				uniform_int_distribution<int> dist(0, 1);
				mt19937 s1;
				s1.seed(random_device{}());
				probability = dist(s1);
				acceptance_probability = exp((min_fitness - fitness) / temperature);
				if (probability < acceptance_probability)
				{
					min_fitness = fitness;
					fout << min_fitness << endl;

					for (int i = 0; i < m * n; i++)
						min_hill[i] = hill[i];
				}
			}
		}
		temperature = first_temperature * pow(step, k);
		k++;
	}
	return min_fitness;
}


int main()
{	
	//Rastrigin = 1 ; DeJong = 2 ;  Michalewicz = 3 ;  Rosenbrock = 4 ;
	
	SA(2, -5.12, 5.12, 5, 0.99, 30, 1);
	
	//fout << "function minima (SA) Rastrigin = " << SA(1000, -5.12, 5.12, 5, 0.99, 15, 1) << '\n';
			
	//fout << "function minima (SA) DeJong = " << SA(1000,  -5.12, 5.12, 5,  0.99, 2, 2)<<"\n";

	//fout << "function minima (SA) Michalewicz = " << SA(1000, 0, pi, 5, 0.99, 2, 3) << '\n';
		
	/*
	fout << "ACKLEY FUNCTION\n";
	fout << "Dimensiune = 30" << endl;
	fout << "SA" << endl;
	for (int k = 0; k < 30; k++)
	{
		fout  << SA(1000, -15, 30, 5, 0.99, 30, 4) << '\n';
	}
	
	fout << "FIHC" << endl;
	for (int k = 0; k < 30; k++)
	{
		fout << FIHC(100, -15, 30, 5, 30, 4) << '\n';
	}


	fout << "BIHC" << endl;
	for (int k = 0; k < 30; k++)
	{
		fout << BIHC(100, -15, 30, 5, 30, 4) << '\n';
	}
	*/


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
